(() => {
  const CONFIG = {
    ...((window && window.APP_CONFIG) || {}),
    defaultCenter: ((window.APP_CONFIG || {}).defaultCenter) || {
      lat: -0.8917,
      lng: 119.8707,
    },
    defaultZoom: ((window.APP_CONFIG || {}).defaultZoom) || 13,
  };

  const PALU_CENTER = [CONFIG.defaultCenter.lat, CONFIG.defaultCenter.lng];
  const DEFAULT_RADIUS_M = 5000;

  const FALLBACK_PETSHOPS = [
    {
      id: "jeslyn",
      name: "Jeslyn Petshop",
      lat: -0.8869085,
      lng: 119.8715397,
      rating: 4.5,
      userRatingsTotal: 6,
      address: "Palu Barat, Kota Palu",
      source: "fallback",
    },
    {
      id: "faith",
      name: "Faith Petshop",
      lat: -0.8830524,
      lng: 119.8758979,
      rating: 4.5,
      userRatingsTotal: 4,
      address: "Palu Barat, Kota Palu",
      source: "fallback",
    },
    {
      id: "memow",
      name: "Me-mow Petshop",
      lat: -0.890453,
      lng: 119.882583,
      rating: null,
      userRatingsTotal: 0,
      address: "Palu Timur, Kota Palu",
      source: "fallback",
    },
    {
      id: "king",
      name: "King Petshop & Grooming",
      lat: -0.8803138,
      lng: 119.8722627,
      rating: 4.6,
      userRatingsTotal: 164,
      address: "Palu Barat, Kota Palu",
      source: "fallback",
    },
    {
      id: "deyan",
      name: "Deyan Petshop",
      lat: -0.8986076,
      lng: 119.8816215,
      rating: null,
      userRatingsTotal: 0,
      address: "Palu Selatan, Kota Palu",
      source: "fallback",
    },
    {
      id: "satellite",
      name: "Satellite Petshop",
      lat: -0.9064756,
      lng: 119.8799512,
      rating: 4.5,
      userRatingsTotal: 2,
      address: "Palu Selatan, Kota Palu",
      source: "fallback",
    },
    {
      id: "aulia",
      name: "Aulia Home Petshop",
      lat: -0.9069365,
      lng: 119.8702099,
      rating: 5.0,
      userRatingsTotal: 8,
      address: "Palu Selatan, Kota Palu",
      source: "fallback",
    },
    {
      id: "noah",
      name: "Noah Petstore",
      lat: -0.9062358,
      lng: 119.8828971,
      rating: 4.4,
      userRatingsTotal: 98,
      address: "Palu Selatan, Kota Palu",
      source: "fallback",
    },
    {
      id: "kenzo",
      name: "Kenzo Petshop",
      lat: -0.9116352,
      lng: 119.8784613,
      rating: 5.0,
      userRatingsTotal: 4,
      address: "Palu Selatan, Kota Palu",
      source: "fallback",
    },
    {
      id: "zoey",
      name: "Zoey Petshop",
      lat: -0.9229054,
      lng: 119.8644576,
      rating: 5.0,
      userRatingsTotal: 2,
      address: "Palu Selatan, Kota Palu",
      source: "fallback",
    },
  ];

  const state = {
    map: null,
    markersLayer: null,
    markersById: new Map(),
    userMarker: null,
    userAccuracyCircle: null,
    routeControl: null,
    places: [],
    filteredPlaces: [],
    selectedPlaceId: "",
    userLocation: null,
    usingUserLocation: false,
    lastDataSource: "fallback lokal",
    googlePlacesReady: false,
    pendingGoogleLoad: null,
  };

  const els = {};

  document.addEventListener("DOMContentLoaded", init);

  function init() {
    cacheEls();
    initMap();
    bindEvents();

    setUserLocation({
      lat: PALU_CENTER[0],
      lng: PALU_CENTER[1],
      accuracy: null,
      isApproximate: true,
    });

    loadPetshops({ silentStatus: false });

    // Coba geolocation otomatis (graceful fallback jika ditolak)
    requestUserLocation({ silent: true, reloadAfter: true });
  }

  function cacheEls() {
    [
      "locateBtn",
      "usePaluCenterBtn",
      "refreshDataBtn",
      "radiusSelect",
      "searchInput",
      "sortSelect",
      "fitAllBtn",
      "statusBadge",
      "sourceInfo",
      "totalPetshopCount",
      "nearestPetshopName",
      "nearestPetshopDistance",
      "popularPetshopName",
      "popularPetshopMeta",
      "showNearestRouteBtn",
      "showPopularRouteBtn",
      "petshopDropdown",
      "confirmButton",
      "cancelButton",
      "clearSelectionBtn",
      "petshopDetail",
      "petshopList",
      "listCountBadge",
    ].forEach((id) => {
      els[id] = document.getElementById(id);
    });
  }

  function initMap() {
    state.map = L.map("map", {
      zoomControl: true,
      preferCanvas: true,
    }).setView(PALU_CENTER, CONFIG.defaultZoom);

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap contributors',
    }).addTo(state.map);

    state.markersLayer = L.layerGroup().addTo(state.map);
  }

  function bindEvents() {
    els.locateBtn.addEventListener("click", () =>
      requestUserLocation({ silent: false, reloadAfter: true })
    );

    els.usePaluCenterBtn.addEventListener("click", () => {
      setUserLocation({
        lat: PALU_CENTER[0],
        lng: PALU_CENTER[1],
        accuracy: null,
        isApproximate: true,
      });
      state.usingUserLocation = false;
      state.map.setView(PALU_CENTER, CONFIG.defaultZoom);
      loadPetshops();
    });

    els.refreshDataBtn.addEventListener("click", () => loadPetshops());
    els.radiusSelect.addEventListener("change", () => loadPetshops());
    els.searchInput.addEventListener("input", filterSortAndRender);
    els.sortSelect.addEventListener("change", filterSortAndRender);

    els.fitAllBtn.addEventListener("click", fitAllMarkers);

    els.showNearestRouteBtn.addEventListener("click", () => {
      const nearest = getNearestPlace(state.filteredPlaces.length ? state.filteredPlaces : state.places);
      if (!nearest) return setStatus("Tidak ada data petshop.", "error");
      selectPlace(nearest.id, { pan: true });
      drawRouteToPlace(nearest);
    });

    els.showPopularRouteBtn.addEventListener("click", () => {
      const popular = getMostPopularPlace(state.filteredPlaces.length ? state.filteredPlaces : state.places);
      if (!popular) return setStatus("Tidak ada data petshop.", "error");
      selectPlace(popular.id, { pan: true });
      drawRouteToPlace(popular);
    });

    els.petshopDropdown.addEventListener("change", (e) => {
      const id = e.target.value;
      if (!id) return;
      selectPlace(id, { pan: false });
    });

    els.confirmButton.addEventListener("click", () => {
      const id = els.petshopDropdown.value;
      if (!id) {
        setStatus("Pilih petshop dulu.", "error");
        return;
      }
      const place = state.places.find((p) => p.id === id);
      if (!place) return;
      selectPlace(id, { pan: true });
      drawRouteToPlace(place);
    });

    els.cancelButton.addEventListener("click", () => {
      clearRoute();
      setStatus("Rute dihapus.", "ok");
    });

    els.clearSelectionBtn.addEventListener("click", clearSelection);
  }

  async function loadPetshops({ silentStatus = false } = {}) {
    const radius = Number(els.radiusSelect.value || DEFAULT_RADIUS_M);
    const center = state.userLocation || {
      lat: PALU_CENTER[0],
      lng: PALU_CENTER[1],
    };

    if (!silentStatus) setStatus("Memuat data petshop...", "loading");

    let places = [];
    let source = "fallback lokal";

    try {
      places = await fetchPlacesFromGooglePlaces(center, radius);
      if (places.length) {
        source = "Google Maps (Places API)";
      }
    } catch (err) {
      console.warn("Google Places gagal, pakai fallback:", err);
    }

    if (!places.length) {
      places = FALLBACK_PETSHOPS.map((p) => ({ ...p }));
      source = "fallback lokal (manual)";
    }

    state.lastDataSource = source;
    state.places = normalizePlaces(places);

    renderMarkers();
    filterSortAndRender();

    setSourceInfo(source);
    setStatus(
      `${state.places.length} petshop dimuat (${source}).`,
      state.places.length ? "ok" : "error"
    );
  }

  function normalizePlaces(places) {
    const seen = new Set();
    const userLoc = state.userLocation;

    return places
      .filter((p) => Number.isFinite(p.lat) && Number.isFinite(p.lng) && p.name)
      .map((p, idx) => {
        const id = p.id || p.placeId || `${slugify(p.name)}-${idx}`;
        const dedupeKey = `${slugify(p.name)}|${round(p.lat, 5)}|${round(p.lng, 5)}`;
        return {
          id,
          dedupeKey,
          name: p.name,
          lat: Number(p.lat),
          lng: Number(p.lng),
          rating:
            p.rating === null || p.rating === undefined || Number.isNaN(Number(p.rating))
              ? null
              : Number(p.rating),
          userRatingsTotal: Number(p.userRatingsTotal || 0),
          address: p.address || p.vicinity || "Alamat tidak tersedia",
          openNow:
            typeof p.openNow === "boolean"
              ? p.openNow
              : p.openNow === null || p.openNow === undefined
              ? null
              : Boolean(p.openNow),
          placeId: p.placeId || null,
          source: p.source || "google",
          distanceMeters: userLoc ? haversineMeters(userLoc, p) : null,
          popularityScore: computePopularityScore(p),
        };
      })
      .filter((p) => {
        if (seen.has(p.dedupeKey)) return false;
        seen.add(p.dedupeKey);
        return true;
      });
  }

  async function fetchPlacesFromGooglePlaces(center, radius) {
    const apiKey = (CONFIG.googleMapsApiKey || "").trim();
    if (!apiKey) {
      throw new Error("Google Maps API key kosong");
    }

    await ensureGooglePlacesLoaded(apiKey);

    const places = [];
    const service = new google.maps.places.PlacesService(document.createElement("div"));

    const queryResults = await new Promise((resolve, reject) => {
      const request = {
        query: "petshop di Palu Sulawesi Tengah",
        location: new google.maps.LatLng(center.lat, center.lng),
        radius,
      };

      service.textSearch(request, (results, status, pagination) => {
        if (
          status !== google.maps.places.PlacesServiceStatus.OK &&
          status !== google.maps.places.PlacesServiceStatus.ZERO_RESULTS
        ) {
          reject(new Error(`Places textSearch status: ${status}`));
          return;
        }

        let all = Array.isArray(results) ? [...results] : [];

        // Ambil halaman kedua bila ada (opsional, untuk coverage lebih bagus)
        if (pagination && pagination.hasNextPage) {
          setTimeout(() => {
            pagination.nextPage();
          }, 1200);

          const originalCallback = service.textSearch;
          // Tidak mudah hook callback page selanjutnya pada service yang sama tanpa wrapper.
          // Jadi cukup resolve page pertama untuk stabilitas.
          resolve(all);
          return;
        }

        resolve(all);
      });
    });

    queryResults.forEach((item) => {
      const loc = item.geometry && item.geometry.location;
      if (!loc) return;
      places.push({
        id: item.place_id,
        placeId: item.place_id,
        name: item.name,
        lat: typeof loc.lat === "function" ? loc.lat() : loc.lat,
        lng: typeof loc.lng === "function" ? loc.lng() : loc.lng,
        rating: item.rating ?? null,
        userRatingsTotal: item.user_ratings_total ?? 0,
        address: item.formatted_address || item.vicinity || "Alamat tidak tersedia",
        openNow:
          item.opening_hours && typeof item.opening_hours.open_now === "boolean"
            ? item.opening_hours.open_now
            : null,
        source: "google",
      });
    });

    // Kalau hasil sedikit, coba nearbySearch sekitar lokasi user/palu.
    if (places.length < 5) {
      const nearby = await new Promise((resolve, reject) => {
        service.nearbySearch(
          {
            location: new google.maps.LatLng(center.lat, center.lng),
            radius,
            keyword: "petshop",
            type: "pet_store",
          },
          (results, status) => {
            if (
              status !== google.maps.places.PlacesServiceStatus.OK &&
              status !== google.maps.places.PlacesServiceStatus.ZERO_RESULTS
            ) {
              reject(new Error(`Places nearbySearch status: ${status}`));
              return;
            }
            resolve(results || []);
          }
        );
      });

      nearby.forEach((item) => {
        const loc = item.geometry && item.geometry.location;
        if (!loc) return;
        places.push({
          id: item.place_id,
          placeId: item.place_id,
          name: item.name,
          lat: typeof loc.lat === "function" ? loc.lat() : loc.lat,
          lng: typeof loc.lng === "function" ? loc.lng() : loc.lng,
          rating: item.rating ?? null,
          userRatingsTotal: item.user_ratings_total ?? 0,
          address: item.vicinity || item.formatted_address || "Alamat tidak tersedia",
          openNow:
            item.opening_hours && typeof item.opening_hours.open_now === "boolean"
              ? item.opening_hours.open_now
              : null,
          source: "google",
        });
      });
    }

    return places;
  }

  function ensureGooglePlacesLoaded(apiKey) {
    if (state.googlePlacesReady && window.google?.maps?.places) {
      return Promise.resolve();
    }
    if (state.pendingGoogleLoad) return state.pendingGoogleLoad;

    state.pendingGoogleLoad = new Promise((resolve, reject) => {
      if (window.google?.maps?.places) {
        state.googlePlacesReady = true;
        resolve();
        return;
      }

      const existing = document.querySelector("script[data-google-places-loader='1']");
      window.__gmPlacesLoaded = function () {
        state.googlePlacesReady = true;
        resolve();
      };
      window.__gmPlacesLoadError = function () {
        reject(new Error("Gagal memuat Google Maps Places library"));
      };

      if (existing) return;

      const script = document.createElement("script");
      script.src = `https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(
        apiKey
      )}&libraries=places&callback=__gmPlacesLoaded`;
      script.async = true;
      script.defer = true;
      script.dataset.googlePlacesLoader = "1";
      script.onerror = window.__gmPlacesLoadError;
      document.head.appendChild(script);
    })
      .catch((err) => {
        state.pendingGoogleLoad = null;
        throw err;
      })
      .finally(() => {
        // keep resolved promise if success, allow retry if gagal
        if (!state.googlePlacesReady) state.pendingGoogleLoad = null;
      });

    return state.pendingGoogleLoad;
  }

  function renderMarkers() {
    state.markersLayer.clearLayers();
    state.markersById.clear();

    state.places.forEach((place) => {
      const marker = L.marker([place.lat, place.lng]);
      marker.on("click", () => selectPlace(place.id, { pan: false }));
      marker.bindPopup(buildPopupHtml(place), { className: "petshop-popup" });
      marker.addTo(state.markersLayer);
      state.markersById.set(place.id, marker);
    });

    updateUserMarker();
  }

  function updateUserMarker() {
    if (!state.map || !state.userLocation) return;

    if (state.userMarker) state.map.removeLayer(state.userMarker);
    if (state.userAccuracyCircle) state.map.removeLayer(state.userAccuracyCircle);

    const { lat, lng, accuracy, isApproximate } = state.userLocation;

    const userIcon = L.divIcon({
      className: "user-marker-wrapper",
      html: '<div class="user-marker-dot"></div>',
      iconSize: [16, 16],
      iconAnchor: [8, 8],
    });

    state.userMarker = L.marker([lat, lng], { icon: userIcon }).addTo(state.map);
    state.userMarker.bindPopup(
      isApproximate
        ? "Titik awal: Pusat Palu (fallback)"
        : "Titik awal: Lokasi kamu saat ini"
    );

    if (accuracy && Number.isFinite(accuracy)) {
      state.userAccuracyCircle = L.circle([lat, lng], {
        radius: Math.min(accuracy, 300),
        color: "#3b82f6",
        fillColor: "#3b82f6",
        fillOpacity: 0.08,
        weight: 1,
      }).addTo(state.map);
    }
  }

  function filterSortAndRender() {
    const q = (els.searchInput.value || "").trim().toLowerCase();
    const sortBy = els.sortSelect.value || "nearest";

    let items = state.places.filter((p) => {
      if (!q) return true;
      return (
        p.name.toLowerCase().includes(q) ||
        (p.address || "").toLowerCase().includes(q)
      );
    });

    items.sort((a, b) => comparePlaces(a, b, sortBy));
    state.filteredPlaces = items;

    renderPetshopList(items);
    populateDropdown(items);
    updateStats(items);
    syncMarkerHighlights();
  }

  function comparePlaces(a, b, sortBy) {
    switch (sortBy) {
      case "popular":
        return (b.popularityScore || 0) - (a.popularityScore || 0) || nameCompare(a, b);
      case "rating":
        return (b.rating ?? -1) - (a.rating ?? -1) || nameCompare(a, b);
      case "reviews":
        return (b.userRatingsTotal || 0) - (a.userRatingsTotal || 0) || nameCompare(a, b);
      case "name":
        return nameCompare(a, b);
      case "nearest":
      default:
        return (a.distanceMeters ?? Number.MAX_SAFE_INTEGER) - (b.distanceMeters ?? Number.MAX_SAFE_INTEGER) || nameCompare(a, b);
    }
  }

  function nameCompare(a, b) {
    return a.name.localeCompare(b.name, "id");
  }

  function renderPetshopList(items) {
    els.petshopList.innerHTML = "";
    els.listCountBadge.textContent = `${items.length} item`;
    els.totalPetshopCount.textContent = String(items.length);

    if (!items.length) {
      els.petshopList.innerHTML = '<div class="empty-list">Tidak ada petshop yang cocok dengan filter saat ini.</div>';
      if (!state.selectedPlaceId) renderDetail(null);
      return;
    }

    const fragment = document.createDocumentFragment();

    items.forEach((place) => {
      const item = document.createElement("div");
      item.className = `list-item${state.selectedPlaceId === place.id ? " active" : ""}`;
      item.dataset.placeId = place.id;

      const ratingText = place.rating ? `⭐ ${place.rating.toFixed(1)}` : "⭐ -";
      const reviewsText = `${place.userRatingsTotal || 0} review`;
      const distText = place.distanceMeters != null ? formatDistance(place.distanceMeters) : "-";

      item.innerHTML = `
        <div class="list-item-top">
          <h3 class="list-item-title">${escapeHtml(place.name)}</h3>
          <span class="pill">${place.openNow === null ? "Jam ?" : place.openNow ? "Buka" : "Tutup"}</span>
        </div>
        <div class="list-item-tags">
          <span class="tag star">${ratingText}</span>
          <span class="tag">${reviewsText}</span>
          <span class="tag dist">${distText}</span>
        </div>
        <div class="list-item-address">${escapeHtml(place.address || "Alamat tidak tersedia")}</div>
      `;

      item.addEventListener("click", () => selectPlace(place.id, { pan: true }));
      fragment.appendChild(item);
    });

    els.petshopList.appendChild(fragment);
  }

  function populateDropdown(items) {
    const prev = els.petshopDropdown.value;
    els.petshopDropdown.innerHTML = '<option value="">-- Pilih petshop --</option>';
    items.forEach((p) => {
      const option = document.createElement("option");
      option.value = p.id;
      option.textContent = p.distanceMeters != null ? `${p.name} (${formatDistance(p.distanceMeters)})` : p.name;
      els.petshopDropdown.appendChild(option);
    });

    if (items.some((p) => p.id === prev)) {
      els.petshopDropdown.value = prev;
    } else if (items.some((p) => p.id === state.selectedPlaceId)) {
      els.petshopDropdown.value = state.selectedPlaceId;
    }
  }

  function updateStats(items) {
    const nearest = getNearestPlace(items);
    const popular = getMostPopularPlace(items);

    els.nearestPetshopName.textContent = nearest ? nearest.name : "-";
    els.nearestPetshopDistance.textContent = nearest && nearest.distanceMeters != null ? formatDistance(nearest.distanceMeters) : "-";

    els.popularPetshopName.textContent = popular ? popular.name : "-";
    els.popularPetshopMeta.textContent = popular
      ? `${popular.rating ? popular.rating.toFixed(1) : "-"} • ${popular.userRatingsTotal || 0} review`
      : "-";
  }

  function getNearestPlace(items) {
    if (!items || !items.length) return null;
    return [...items].sort((a, b) => (a.distanceMeters ?? Infinity) - (b.distanceMeters ?? Infinity))[0] || null;
  }

  function getMostPopularPlace(items) {
    if (!items || !items.length) return null;
    return [...items].sort((a, b) => (b.popularityScore || 0) - (a.popularityScore || 0))[0] || null;
  }

  function selectPlace(id, { pan = true } = {}) {
    const place = state.places.find((p) => p.id === id);
    if (!place) return;

    state.selectedPlaceId = id;
    els.petshopDropdown.value = id;

    renderDetail(place);
    syncListActiveItem();
    syncMarkerHighlights();

    const marker = state.markersById.get(id);
    if (marker) {
      if (pan) state.map.flyTo([place.lat, place.lng], Math.max(state.map.getZoom(), 15), { duration: 0.5 });
      marker.openPopup();
    }
  }

  function clearSelection() {
    state.selectedPlaceId = "";
    els.petshopDropdown.value = "";
    renderDetail(null);
    syncListActiveItem();
    syncMarkerHighlights();
  }

  function renderDetail(place) {
    if (!place) {
      els.petshopDetail.className = "detail-empty";
      els.petshopDetail.textContent = "Pilih marker atau item petshop untuk melihat detail.";
      return;
    }

    els.petshopDetail.className = "detail-content";
    const distanceText = place.distanceMeters != null ? formatDistance(place.distanceMeters) : "-";
    const ratingText = place.rating != null ? place.rating.toFixed(1) : "-";
    const reviewsText = place.userRatingsTotal || 0;
    const statusText = place.openNow === null ? "Tidak diketahui" : place.openNow ? "Sedang buka" : "Sedang tutup";
    const mapsLink = buildGoogleMapsLink(place);

    els.petshopDetail.innerHTML = `
      <h3>${escapeHtml(place.name)}</h3>
      <div class="detail-meta">
        <div class="meta-row"><span>Jarak</span><strong>${distanceText}</strong></div>
        <div class="meta-row"><span>Rating</span><strong>${ratingText}</strong></div>
        <div class="meta-row"><span>Review</span><strong>${reviewsText}</strong></div>
        <div class="meta-row"><span>Status</span><strong>${escapeHtml(statusText)}</strong></div>
      </div>
      <p class="address">${escapeHtml(place.address || "Alamat tidak tersedia")}</p>
      <div class="detail-actions">
        <button id="detailRouteBtn" class="btn btn-primary">Buat Rute</button>
        <a class="btn btn-secondary" href="${mapsLink}" target="_blank" rel="noopener noreferrer">Buka di Maps</a>
      </div>
    `;

    const detailRouteBtn = document.getElementById("detailRouteBtn");
    if (detailRouteBtn) {
      detailRouteBtn.addEventListener("click", () => drawRouteToPlace(place));
    }
  }

  function syncListActiveItem() {
    els.petshopList.querySelectorAll(".list-item").forEach((item) => {
      item.classList.toggle("active", item.dataset.placeId === state.selectedPlaceId);
    });
  }

  function syncMarkerHighlights() {
    state.markersById.forEach((marker, id) => {
      const isActive = id === state.selectedPlaceId;
      const el = marker.getElement && marker.getElement();
      if (el) {
        el.style.filter = isActive ? "hue-rotate(-20deg) saturate(1.5)" : "";
        el.style.transform = isActive ? "translateY(-2px)" : "";
      }
    });
  }

  function drawRouteToPlace(place) {
    if (!place) return;
    if (!state.userLocation) {
      setStatus("Lokasi awal belum tersedia.", "error");
      return;
    }

    clearRoute();

    state.routeControl = L.Routing.control({
      waypoints: [
        L.latLng(state.userLocation.lat, state.userLocation.lng),
        L.latLng(place.lat, place.lng),
      ],
      routeWhileDragging: false,
      addWaypoints: false,
      draggableWaypoints: false,
      fitSelectedRoutes: true,
      show: false,
      createMarker: () => null,
      lineOptions: {
        styles: [{ color: "#f59e0b", opacity: 0.9, weight: 5 }],
      },
    })
      .on("routesfound", (e) => {
        const route = e.routes?.[0];
        const summary = route?.summary;
        if (summary) {
          setStatus(
            `Rute ke ${place.name}: ${formatDistance(summary.totalDistance)} • ${formatDuration(summary.totalTime)}`,
            "ok"
          );
        } else {
          setStatus(`Rute ke ${place.name} berhasil ditampilkan.`, "ok");
        }
      })
      .on("routingerror", () => {
        setStatus("Gagal menghitung rute. Coba lagi atau pilih petshop lain.", "error");
      })
      .addTo(state.map);
  }

  function clearRoute() {
    if (state.routeControl) {
      state.map.removeControl(state.routeControl);
      state.routeControl = null;
    }
  }

  async function requestUserLocation({ silent = false, reloadAfter = false } = {}) {
    if (!navigator.geolocation) {
      if (!silent) setStatus("Browser tidak mendukung geolocation.", "error");
      return;
    }

    if (!silent) setStatus("Mengambil lokasi kamu...", "loading");

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude, accuracy } = pos.coords;
        state.usingUserLocation = true;
        setUserLocation({ lat: latitude, lng: longitude, accuracy, isApproximate: false });
        state.map.flyTo([latitude, longitude], 14, { duration: 0.5 });
        if (!silent) setStatus("Lokasi berhasil diperbarui.", "ok");
        if (reloadAfter) loadPetshops({ silentStatus: true });
      },
      (err) => {
        console.warn("Geolocation error:", err);
        if (!silent) {
          let message = "Tidak bisa mengakses lokasi. Menggunakan pusat Palu sebagai titik awal.";
          if (err.code === 1) message = "Akses lokasi ditolak. Menggunakan pusat Palu sebagai titik awal.";
          setStatus(message, "error");
        }
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 1000 * 60 * 2,
      }
    );
  }

  function setUserLocation({ lat, lng, accuracy = null, isApproximate = false }) {
    state.userLocation = { lat, lng, accuracy, isApproximate };
    // Recompute distance jika data sudah ada
    if (state.places.length) {
      state.places = state.places.map((p) => ({
        ...p,
        distanceMeters: haversineMeters({ lat, lng }, p),
        popularityScore: computePopularityScore(p),
      }));
      filterSortAndRender();
    }
    updateUserMarker();
  }

  function fitAllMarkers() {
    const bounds = [];
    if (state.userLocation) bounds.push([state.userLocation.lat, state.userLocation.lng]);
    state.filteredPlaces.forEach((p) => bounds.push([p.lat, p.lng]));

    if (bounds.length === 0) {
      state.map.setView(PALU_CENTER, CONFIG.defaultZoom);
      return;
    }

    state.map.fitBounds(bounds, { padding: [32, 32], maxZoom: 15 });
  }

  function setStatus(text, type = "ok") {
    els.statusBadge.textContent = text;
    els.statusBadge.classList.remove("loading", "error");
    if (type === "loading") els.statusBadge.classList.add("loading");
    if (type === "error") els.statusBadge.classList.add("error");
  }

  function setSourceInfo(source) {
    els.sourceInfo.textContent = `Sumber data: ${source}`;
  }

  function buildPopupHtml(place) {
    return `
      <div class="petshop-popup">
        <h4>${escapeHtml(place.name)}</h4>
        <p class="popup-meta">⭐ ${place.rating != null ? place.rating.toFixed(1) : "-"} • ${place.userRatingsTotal || 0} review</p>
        <p class="popup-meta">📍 ${escapeHtml(place.address || "Alamat tidak tersedia")}</p>
        <p class="popup-meta">📏 ${place.distanceMeters != null ? formatDistance(place.distanceMeters) : "-"}</p>
      </div>
    `;
  }

  function computePopularityScore(place) {
    const rating = Number(place.rating || 0);
    const reviews = Number(place.userRatingsTotal || 0);
    if (!rating && !reviews) return 0;
    // Skor sederhana: rating dipertahankan + bobot logarithmic review count
    return rating * Math.log10(reviews + 10);
  }

  function haversineMeters(a, b) {
    const R = 6371000;
    const dLat = degToRad(b.lat - a.lat);
    const dLng = degToRad(b.lng - a.lng);
    const lat1 = degToRad(a.lat);
    const lat2 = degToRad(b.lat);

    const sinDLat = Math.sin(dLat / 2);
    const sinDLng = Math.sin(dLng / 2);
    const x =
      sinDLat * sinDLat + Math.cos(lat1) * Math.cos(lat2) * sinDLng * sinDLng;
    const c = 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
    return R * c;
  }

  function degToRad(d) {
    return (d * Math.PI) / 180;
  }

  function formatDistance(meters) {
    if (!Number.isFinite(meters)) return "-";
    if (meters < 1000) return `${Math.round(meters)} m`;
    return `${(meters / 1000).toFixed(2)} km`;
  }

  function formatDuration(sec) {
    if (!Number.isFinite(sec)) return "-";
    const totalMinutes = Math.round(sec / 60);
    if (totalMinutes < 60) return `${totalMinutes} menit`;
    const h = Math.floor(totalMinutes / 60);
    const m = totalMinutes % 60;
    return `${h} jam${m ? ` ${m} menit` : ""}`;
  }

  function escapeHtml(str) {
    return String(str ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/\"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function slugify(s) {
    return String(s)
      .toLowerCase()
      .normalize("NFKD")
      .replace(/[^a-z0-9\s-]/g, "")
      .trim()
      .replace(/\s+/g, "-");
  }

  function round(n, p = 5) {
    const f = Math.pow(10, p);
    return Math.round(n * f) / f;
  }

  function buildGoogleMapsLink(place) {
    if (place.placeId) {
      return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
        place.name
      )}&query_place_id=${encodeURIComponent(place.placeId)}`;
    }
    return `https://www.google.com/maps/search/?api=1&query=${place.lat},${place.lng}`;
  }
})();
